src_ip = "192.168.0.1"
dst_ip = "192.168.0.10"
intermediate_ips = ["192.168.0.2", "192.168.0.3", "192.168.0.4"]
protocol_values = {1, 17}
fragment_counts = {1001: 3}
last_offsets = {1001: 1480}
avg_rtt, std_dev_rtt = 50.6, 4.0  # Example RTT data to ultimate destination
probes_per_ttl = {1: 3, 2: 3, 3: 2}  # Example probes per TTL
answer_second_question = "Yes"  # Example answer for the second question
answer_third_question = "No"  # Example answer for the third question

# Print the table with horizontal line dividers
print(f"{'Row':<5} {'Components':<60} {'Details'}")
print("=" * 90)

# Display each rubric component with row numbers and horizontal dividers
print(f"{'1':<5} {'The IP address of the source node (R1)':<60} {src_ip}")
print("-" * 90)
print(f"{'2':<5} {'The IP address of ultimate destination node (R1)':<60} {dst_ip}")
print("-" * 90)
print(f"{'3':<5} {'The IP addresses of the intermediate destination nodes (R1)':<60} {', '.join(intermediate_ips)}")
print("-" * 90)
print(f"{'4':<5} {'The correct order of the intermediate destination nodes (R1)':<60} {', '.join(intermediate_ips)}")
print("-" * 90)

# Protocol values
protocol_details = ", ".join(f"{p}: {'ICMP' if p == 1 else 'UDP' if p == 17 else 'Unknown'}" for p in protocol_values)
print(f"{'5':<5} {'The values in the protocol field of IP headers (R1)':<60} {protocol_details}")
print("-" * 90)

# Fragmentation details for single datagram
datagram_id = list(fragment_counts.keys())[0]
print(f"{'6':<5} {'The number of fragments created from the original datagram (R1)':<60} {fragment_counts[datagram_id]}")
print("-" * 90)
print(f"{'7':<5} {'The offset of the last fragment (R1)':<60} {last_offsets[datagram_id]}")
print("-" * 90)

# RTT details
print(f"{'8':<5} {'The avg RTT to ultimate destination node (R1)':<60} {avg_rtt} ms")
print("-" * 90)
print(f"{'9':<5} {'The std deviation of RTT to ultimate destination node (R1)':<60} {std_dev_rtt} ms")
print("-" * 90)

# Probes and question answers
print(f"{'10':<5} {'The number of probes per TTL (R2)':<60} {', '.join(f'TTL {ttl}: {probes}' for ttl, probes in probes_per_ttl.items())}")
print("-" * 90)
print(f"{'11':<5} {'Right answer to the second question (R2)':<60} {answer_second_question}")
print("-" * 90)
print(f"{'12':<5} {'Right answer to the third/or fourth question (R2)':<60} {answer_third_question}")
print("=" * 90)